
===

HALLOWEEN GRAPHICS

===


Hello! Thank you for downloading this mini asset pack.

The graphics in this pack were all originally made for my patreon supporters, over the past two years.
I've gathered them all here together for a themed release for Halloween.

https://www.patreon.com/finalbossblues

Thanks!

===

UPDATE: 10/31/2019

Happy Halloween 2019! I've updated the pack to include this year's releases: 
skulls and dancing skeletons for Day of the Dead!

I've also added a new battler monster that was contributed by Tyler Warren! 
It matches the Headless Horseman sprite.
Check out Tyler's stuff here: https://tylerjwarren.itch.io

===

UPDATE: 10/30/2022

Happy Halloween 2022! Been a while since I've updated this set.

I added new full-character sheets for the Day of the Dead skeletons! 
They're now complete characters.

===

http://finalbossblues.com
http://timefantasy.net
https://finalbossblues.itch.io
